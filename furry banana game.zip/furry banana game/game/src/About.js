import React from 'react';

const AboutUs = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>About Us</h1>
      <p style={styles.description}>
        Welcome to Fury Banana! We are passionate about making learning fun through interactive and engaging games. Our goal is to provide entertainment and education in a playful way. Let's learn, grow, and have fun together!
      </p>
      <div style={styles.socialIcons}>
        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/e/e7/Instagram_logo_2016.svg"
            alt="Instagram"
            style={styles.icon}
          />
        </a>
        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/1/1b/Facebook_icon.svg"
            alt="Facebook"
            style={styles.icon}
          />
        </a>
        <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
          <img
            src="https://th.bing.com/th/id/OIP.kE-izi3Uki1nxiDmy4f5mQHaHa?w=626&h=626&rs=1&pid=ImgDetMain"
            alt="Twitter"
            style={styles.icon}
          />
        </a>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    backgroundColor: '#34D399',
    color: 'white',
    padding: '20px',
    textAlign: 'center',
  },
  heading: {
    fontSize: '2.5rem',
    marginBottom: '20px',
    fontWeight: 'bold',
  },
  description: {
    fontSize: '1.2rem',
    maxWidth: '600px',
    marginBottom: '30px',
  },
  socialIcons: {
    display: 'flex',
    justifyContent: 'center',
    gap: '20px',
  },
  icon: {
    width: '50px',
    height: '50px',
    cursor: 'pointer',
  },
};

export default AboutUs;