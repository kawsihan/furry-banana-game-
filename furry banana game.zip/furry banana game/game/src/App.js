import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Home from './Home';
import Register from './Register';
import Login from './Login';
import Game from './game';
import Start from './start';
import Scoreboard from './scorebord';
import AboutUs from './About';
import Timeout from './Timeout';
import SettingsPage from './Settingspage';


function App() {
  return (
    <Router>
     
        <Routes>
          <Route path="/Home" element={<Home />} />
          <Route path="/Register" element={<Register />} />
          <Route path="/Login" element={<Login />}/>
          <Route path="/Game" element={<Game />} />
          <Route path ="/start" element={<Start />}/>
          <Route path ="/scorebord" element={<Scoreboard />}/>
          <Route path ="/Aboutus" element={<AboutUs />}/>
          <Route path ="/Timeout" element={<Timeout />}/>
          <Route path ="/Settingspage" element={<SettingsPage />}/>
        </Routes>
     
    </Router>
  );
}

export default App;