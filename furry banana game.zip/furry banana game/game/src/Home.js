import React from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  // Logout handler
  const handleLogout = () => {
    localStorage.removeItem('token'); // Clear the JWT token
    navigate('/login'); // Navigate to the login page
  };

  const handlePlay = () => {
    navigate('/game'); // Navigate to Game.js
  };

  const handleScoreBoard = () => {
    navigate('/scorebord'); // Navigate to Score.js
  };

  const handleAbout = () => {
    navigate('/Aboutus'); // Navigate to About.js
  };

  const handleSettings = () => {
    navigate('/Settingspage'); // Navigate to Settings.js
  };

  return (
    <div style={styles.outerContainer}>
      {/* Logout button */}
      <button onClick={handleLogout} style={styles.logoutButton}>
        Logout
      </button>

      {/* Left side for the monkey image */}
      <div style={styles.leftSide}>
        <img src="banana.png" alt="Monkey" style={styles.monkeyImage} />
      </div>

      {/* Right side for the buttons */}
      <div style={styles.rightSide}>
        <div style={styles.buttonContainer}>
          <button style={{ ...styles.button, backgroundColor: '#FF9800' }} onClick={handlePlay}>Play</button>
          <button style={{ ...styles.button, backgroundColor: '#FFEB3B' }} onClick={handleScoreBoard}>Score Board</button>
          <button style={{ ...styles.button, backgroundColor: '#9C27B0' }} onClick={handleAbout}>About</button>
          <button style={{ ...styles.button, backgroundColor: '#4CAF50' }} onClick={handleSettings}>Settings</button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  outerContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundImage: 'url("dasbord.jpg")', // Fullscreen background image
    backgroundSize: 'cover',
    position: 'relative',
    margin: 0,
    padding: 0,
  },
  leftSide: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '50%',
  },
  rightSide: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '50%',
  },
  monkeyImage: {
    width: '100%',
    height: 'auto',
  },
  buttonContainer: {
    backgroundColor: 'rgba(240, 240, 240, 0.9)', 
    padding: '60px',
    borderRadius: '30px',
    boxShadow: '0 0 15px rgba(0, 0, 0, 0.2)',
    width: '370px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    position: 'relative',
    height: '380px',
    overflow: 'visible',
    left: '-150px',
  },
  button: {
    width: '100%',
    padding: '20px', 
    marginBottom: '10px', 
    borderRadius: '30px',
    border: 'none',
    color: '#fff',
    fontSize: '24px', 
    cursor: 'pointer',
    fontFamily: 'Arial, sans-serif',
    textTransform: 'capitalize',
  },
  logoutButton: {
    position: 'absolute',
    top: '20px',
    right: '20px',
    backgroundColor: '#FF5252',
    color: '#fff',
    padding: '10px 20px',
    borderRadius: '30px',
    border: 'none',
    fontSize: '16px',
    cursor: 'pointer',
    fontFamily: 'Arial, sans-serif',
  },
};

export default Home;