import React from 'react';

const SettingsPage = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>Game Settings</h1>
      <div style={styles.settingsContainer}>
        {/* Left Menu */}
        <div style={styles.menu}>
          <button style={styles.menuButton}>General</button>
          <button style={styles.menuButton}>Language</button>
          <button style={styles.menuButton}>Control</button>
          <button style={styles.menuButton}>Graphics</button>
          <button style={styles.menuButton}>Visuals</button>
          <button style={{ ...styles.menuButton, ...styles.activeButton }}>
            Audio
          </button>
        </div>

        {/* Right Settings */}
        <div style={styles.settings}>
          <div style={styles.settingItem}>
            <label style={styles.label}>Music</label>
            <input type="range" style={styles.slider} defaultValue="60" />
          </div>
          <div style={styles.settingItem}>
            <label style={styles.label}>Sound Effect</label>
            <input type="range" style={styles.slider} defaultValue="80" />
          </div>
          <div style={styles.settingItem}>
            <label style={styles.label}>Ambient Sound</label>
            <input type="range" style={styles.slider} defaultValue="30" />
          </div>
          <div style={styles.settingItem}>
            <label style={styles.label}>Voice Over</label>
            <input type="range" style={styles.slider} defaultValue="45" />
          </div>
          <div style={styles.settingItem}>
            <label style={styles.label}>Message Sound</label>
            <input type="range" style={styles.slider} defaultValue="35" />
          </div>

          {/* Buttons */}
          <div style={styles.buttons}>
            <button style={styles.actionButton}>Apply</button>
            <button style={styles.actionButton}>Reset</button>
            <button style={styles.actionButton}>Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    backgroundColor: '#FDE68A', // Yellow background
    padding: '20px',
  },
  heading: {
    fontSize: '2.5rem',
    color: '#10B981', // Green text
    marginBottom: '20px',
    fontWeight: 'bold',
  },
  settingsContainer: {
    display: 'flex',
    width: '80%',
    height: 'auto',
    justifyContent: 'space-between',
    gap: '20px',
  },
  menu: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    flex: 1,
  },
  menuButton: {
    backgroundColor: '#34D399', // Green background
    color: '#FFF', // White text
    border: 'none',
    padding: '10px 20px',
    borderRadius: '5px',
    cursor: 'pointer',
    textAlign: 'center',
    fontSize: '1rem',
  },
  activeButton: {
    backgroundColor: '#FB923C', // Orange background for active
  },
  settings: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
    flex: 2,
  },
  settingItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '15px',
  },
  label: {
    fontSize: '1.2rem',
    color: '#10B981', // Green text
    flex: 1,
  },
  slider: {
    flex: '2',
    appearance: 'none',
    width: '100%',
    height: '8px',
    backgroundColor: '#34D399', // Green
    borderRadius: '5px',
    outline: 'none',
    cursor: 'pointer',
    margin: '0 10px',
  },
  buttons: {
    display: 'flex',
    gap: '15px',
    marginTop: '20px',
    justifyContent: 'flex-end',
  },
  actionButton: {
    backgroundColor: '#FB923C', // Orange background
    color: '#FFF', // White text
    border: 'none',
    padding: '10px 20px',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '1rem',
  },
};

export default SettingsPage;