import React from 'react';

import { useNavigate } from 'react-router-dom';


const Start = () => {

 const navigate = useNavigate();


 // Navigation handler for the button

 const handleLogin = () => {

 navigate('/login'); // Navigate to Login.js

 };


 return (

<div style={styles.outerContainer}>

 <div style={styles.centerContent}>

 {/* Image in the middle of the screen */}

 <img src="banana.png" alt="Logo" style={styles.centerImage} />
 
 {/* Login button */}
 <button style={styles.loginButton} onClick={handleLogin}>

 Login to Play

 </button>

 </div>

 </div>

);

};


const styles = {

 outerContainer: {

 display: 'flex',

 justifyContent: 'center',

 alignItems: 'center',

 height: '100vh',

backgroundImage: 'url("open.jpg")', // Fullscreen background image

 backgroundSize: 'cover',

 position: 'relative',

 margin: 0,

 padding: 0,
 },

 centerContent: {

 textAlign: 'center', // Center content inside

 color: 'white', // Text color for better visibility on the background

 },

 centerImage: {

 width: '500px', // Adjust the size of the image

 height: 'auto',

 marginBottom: '30px', // More space between the image and the button

 },

 loginButton: {

 backgroundColor: 'Green', // Green button color

 color: 'white',

 padding: '20px 40px',

 fontSize: '24px',

 border: 'none',

 borderRadius: '10px',

 cursor: 'pointer',

 width: '300px', // Button width

 textTransform: 'uppercase',

 marginTop: '20px', // Space between the image and the button

 },

};


export default Start;