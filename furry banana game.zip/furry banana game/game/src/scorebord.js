import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Confetti from 'react-confetti';

const Scoreboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { score } = location.state || { score: 0 };
  const [windowDimensions, setWindowDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  // Update dimensions on resize for confetti
  useEffect(() => {
    const handleResize = () => {
      setWindowDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handlePlayAgain = () => {
    navigate('/game');
  };

  const handleQuit = () => {
    navigate('/Home');
  };

  return (
    <div style={styles.scoreboardContainer}>
      {/* Fireworks animation */}
      <Confetti
        width={windowDimensions.width}
        height={windowDimensions.height}
        numberOfPieces={300}
        gravity={0.1}
      />
      <div style={styles.overlay}></div>
      <div style={styles.scoreboardBox}>
        <h2 style={styles.headerText}>🎉 YOU WIN! 🎉</h2>
        <p style={styles.scoreText}>SCORE: {score}</p>
        <div style={styles.buttons}>
          <button style={styles.playAgainButton} onClick={handlePlayAgain}>
            Play Again
          </button>
          <button style={styles.quitButton} onClick={handleQuit}>
            Quit
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  scoreboardContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundImage:
      'url("https://img.freepik.com/premium-vector/cartoon-illustration-path-with-tree-path_135595-81548.jpg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    position: 'relative',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  scoreboardBox: {
    position: 'relative',
    backgroundColor: '#ffffff',
    padding: '40px',
    borderRadius: '15px',
    textAlign: 'center',
    width: '400px',
    boxShadow: '0 8px 15px rgba(0, 0, 0, 0.3)',
    zIndex: 1,
  },
  headerText: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#34D399',
    marginBottom: '15px',
    textShadow: '2px 2px #000',
  },
  scoreText: {
    fontSize: '22px',
    fontWeight: 'bold',
    color: '#F97316',
    marginBottom: '20px',
  },
  buttons: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '20px',
  },
  playAgainButton: {
    backgroundColor: '#22C55E',
    color: 'white',
    fontSize: '16px',
    padding: '12px 25px',
    border: 'none',
    borderRadius: '30px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
    boxShadow: '0 5px 10px rgba(0, 0, 0, 0.2)',
  },
  quitButton: {
    backgroundColor: '#EF4444',
    color: 'white',
    fontSize: '16px',
    padding: '12px 25px',
    border: 'none',
    borderRadius: '30px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
    boxShadow: '0 5px 10px rgba(0, 0, 0, 0.2)',
  },
};

export default Scoreboard;