import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const Timeout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { score } = location.state || { score: 0 };

  const handlePlayAgain = () => {
    navigate('/game');
  };

  const handleQuit = () => {
    navigate('/Home');
  };

  return (
    <div style={styles.timeoutContainer}>
      <div style={styles.overlay}></div>
      <div style={styles.timeoutBox}>
        <h2 style={styles.headerText}>
          Time Up! <span style={styles.sadEmoji}>😔</span>
        </h2>
        <p style={styles.scoreText}>Your Score: {score}</p>
        <div style={styles.buttons}>
          <button style={styles.playAgainButton} onClick={handlePlayAgain}>
            Play Again
          </button>
          <button style={styles.quitButton} onClick={handleQuit}>
            Quit
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  timeoutContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundImage:
      'url("https://img.freepik.com/premium-vector/cartoon-illustration-path-with-tree-path_135595-81548.jpg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    position: 'relative',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  timeoutBox: {
    position: 'relative',
    backgroundColor: '#ffffff',
    padding: '40px',
    borderRadius: '15px',
    textAlign: 'center',
    width: '400px',
    boxShadow: '0 8px 15px rgba(0, 0, 0, 0.3)',
    zIndex: 1,
  },
  headerText: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#FF5722',
    marginBottom: '15px',
    textShadow: '2px 2px #000',
  },
  sadEmoji: {
    fontSize: '32px',
    marginLeft: '10px',
  },
  scoreText: {
    fontSize: '22px',
    fontWeight: 'bold',
    color: '#F97316',
    marginBottom: '20px',
  },
  buttons: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '20px',
  },
  playAgainButton: {
    backgroundColor: '#22C55E',
    color: 'white',
    fontSize: '16px',
    padding: '12px 25px',
    border: 'none',
    borderRadius: '30px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
    boxShadow: '0 5px 10px rgba(0, 0, 0, 0.2)',
  },
  quitButton: {
    backgroundColor: '#EF4444',
    color: 'white',
    fontSize: '16px',
    padding: '12px 25px',
    border: 'none',
    borderRadius: '30px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
    boxShadow: '0 5px 10px rgba(0, 0, 0, 0.2)',
  },
};

export default Timeout;