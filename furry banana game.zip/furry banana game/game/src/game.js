import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const BananaGame = () => {
  const navigate = useNavigate();
  const [stage, setStage] = useState(1);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [question, setQuestion] = useState('');
  const [solution, setSolution] = useState(-1);
  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState('Waiting for first game...');
  const [isGameActive, setIsGameActive] = useState(false); 
  
  const audioRef = useRef(null);
  const musicUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'; 

  // Initialize the audio
  useEffect(() => {
    audioRef.current = new Audio(musicUrl);
  }, [musicUrl]);

  // Play or stop music based on game state
  useEffect(() => {
    if (isGameActive) {
      audioRef.current.play().catch((error) => {
        console.error('Error playing the audio:', error);
      });
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0; 
      }
    }
  }, [isGameActive]);

  // Fetch a new question
  const fetchNewQuestion = async () => {
    try {
      const response = await fetch('https://marcconrad.com/uob/banana/api.php');
      const data = await response.text();
      const parsedData = JSON.parse(data);
      setQuestion(parsedData.question);
      setSolution(parsedData.solution);
      setFeedback('Quest is ready.');
    } catch (error) {
      console.error('Error fetching question:', error);
      setFeedback('Error loading question.');
    }
  };

  // Save the final score to the backend
  const saveScoreToDatabase = useCallback(async () => {
    try {
      const response = await axios.post('http://localhost:5000/save-score', {
        score,
        userId: 'userId-from-login', 
      });
      console.log(response.data.message);
    } catch (error) {
      console.error('Error saving score:', error);
    }
  }, [score]);

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0 && isGameActive) {
      const timer = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && isGameActive) {
      alert('Time is up! Better luck next time.');
      saveScoreToDatabase();
      setIsGameActive(false); 
      navigate('/Timeout', { state: { score } });
    }
  }, [timeLeft, isGameActive, saveScoreToDatabase, navigate, score]);

  // Start the game
  const startGame = () => {
    setStage(1);
    setScore(0);
    setTimeLeft(60); 
    setIsGameActive(true); 
    fetchNewQuestion();
  };

  // Proceed to next stage or end game
  const handleNextStage = () => {
    if (input && parseInt(input) === solution) {
      if (stage < 5) {
        setStage(stage + 1);
        setScore(score + 100);
        setTimeLeft(60 - stage * 10); 
      } else {
        alert('Congratulations! You completed all 5 levels!');
        saveScoreToDatabase();
        setIsGameActive(false); 
        navigate('/scorebord', { state: { score: score + 100 } });
      }
    } else {
      setFeedback('Incorrect! Try again.');
    }
    setInput('');
    fetchNewQuestion();
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const value = e.target.value;
    setInput(value);
    if (parseInt(value) === solution) {
      setFeedback('Correct! Great job!');
    } else {
      setFeedback('Not correct! Try again.');
    }
  };

  return (
    <div style={styles.gameContainer}>
      {isGameActive ? (
        <>
          <div style={styles.gameInfo}>
            <div style={styles.infoEgg('#FDE68A')}>
              <p>Stage:</p>
              <p>{stage}</p>
            </div>
            <div style={styles.infoEgg('#34D399')}>
              <p>Score:</p>
              <p>{score}</p>
            </div>
            <div style={styles.infoEgg('#F97316')}>
              <p>Time Left:</p>
              <p>{timeLeft}s</p>
            </div>
          </div>

          <div style={styles.gameContent}>
            <img style={styles.questionImage} src={question} alt="Quest" />
            <h3 style={styles.feedback}>{feedback}</h3>
            <input
              style={styles.inputBox}
              type="number"
              value={input}
              onChange={handleInputChange}
            />
            <button style={styles.startButton} onClick={handleNextStage}>
              Next
            </button>
          </div>
        </>
      ) : (
        <button style={styles.startButton} onClick={startGame}>
          Start Game
        </button>
      )}
    </div>
  );
};





// Inline CSS styles
const styles = {
  gameContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    background: "url('https://img.freepik.com/premium-vector/cartoon-illustration-path-with-tree-path_135595-81548.jpg') no-repeat center center",
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
    color: 'white',
    textAlign: 'center',
  },
  gameInfo: {
    display: 'flex',
    flexDirection: 'column',
    position: 'absolute',
    top: '95px',
    left: '90px',
    gap: '15px',
  },
  infoEgg: (bgColor) => ({
    padding: '20px 35px',
    borderRadius: '50px',
    textAlign: 'center',
    fontSize: '1.2rem',
    color: 'white',
    fontWeight: 'bold',
    boxShadow: '0 3px 8px rgba(0, 0, 0, 0.3)',
    backgroundColor: bgColor,
  }),
  questionImage: {
    maxWidth: '100%',
    height: 'auto',
    marginBottom: '15px',
  },
  feedback: {
    fontSize: '1.5rem',
    marginBottom: '20px',
  },
  inputBox: {
    padding: '10px',
    fontSize: '1.2rem',
    width: '20%',
    marginBottom: '15px',
  },
  startButton: {
    backgroundColor: 'Green',
    color: 'white',
    padding: '12px 25px',
    fontSize: '1.2rem',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    width: '40%',
    marginTop: '15px',
    display: 'block',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  gameContent: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
};

export default BananaGame;