import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom'; // Import Link from react-router-dom

const Registration = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState(null); // State to handle error messages
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      const response = await axios.post('http://localhost:5000/register', {
        name,
        email,
        password,
        confirmPassword,
      });

      if (response.data.message === 'User registered successfully') {
        alert('Rgistration successful!');
        navigate('/login');
      }
    } catch (error) {
      console.error('Error during registration:', error);
      setError(error.response ? error.response.data.error : 'An error occurred');
    }
  };

  const handleCancel = () => {
    navigate('/login');
  };

  return (
    <div style={styles.registrationContainer}>
      <div style={styles.leftSide}>
        <img src="banana.png" alt="Monkey" style={styles.monkeyImage} />
      </div>

      <div style={styles.formContainer}>
        <button type="button" style={styles.cancelButton} onClick={handleCancel}>✖</button>
        <form onSubmit={handleSubmit} style={styles.registrationForm}>
          <input
            type="text"
            placeholder="Full Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="email"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            style={styles.input}
          />
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <button type="submit" style={styles.registerButton}>Register Here!</button>
        </form>
        <p style={styles.loginLink}>
          Do you have an account? <Link to="/login">Login here</Link>
        </p> {/* Link to Login page */}
      </div>
    </div>
  );
};

const styles = {
  registrationContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundImage: 'url("register.jpg")',
    backgroundSize: 'cover',
    position: 'relative',
  },
  leftSide: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    width: '50%',
  },
  monkeyImage: {
    width: '100%',
  },
  formContainer: {
    backgroundColor: 'rgba(240, 240, 240, 0.9)',
    padding: '60px',
    borderRadius: '30px',
    boxShadow: '0 0 15px rgba(0, 0, 0, 0.2)',
    width: '370px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    position: 'relative',
    height: '380px',
    overflow: 'visible',
  },
  cancelButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    color: '#ff5a5a',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '22px',
  },
  input: {
    width: '100%',
    padding: '10px',
    margin: '10px 0',
    borderRadius: '20px',
    border: '1px solid #ccc',
    fontSize: '16px',
  },
  registerButton: {
    width: '100%',
    padding: '10px',
    borderRadius: '20px',
    border: 'none',
    backgroundColor: '#4CAF50',
    color: 'white',
    fontSize: '16px',
    cursor: 'pointer',
    marginTop: '20px',
  },
  registrationForm: {
    display: 'flex',
    flexDirection: 'column',
  },
  loginLink: {
    marginTop: '10px',
    textAlign: 'center',
  },
};

export default Registration;