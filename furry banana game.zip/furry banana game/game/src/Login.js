import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './App.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/login', {
        email,
        password,
      });

      if (response.data.message === 'Login successful') {
        alert('Login successful!');
        window.location.href = '/home';
      } else {
        setError('Invalid email or password');
      }
    } catch (error) {
      console.error('Error during login:', error);
      setError(error.response ? error.response.data.error : 'An error occurred');
    }
  };

  const handleCancel = () => {
    window.location.href = '/home';
  };

  return (
    <div style={styles.container}>
      <div style={styles.leftSide}>
        <img src="banana.png" alt="Monkey" style={styles.monkeyImage} />
      </div>

      <div style={styles.formContainer}>
        <button type="button" style={styles.cancelButton} onClick={handleCancel}>✖</button>
        <form onSubmit={handleLogin} style={styles.form}>
          <input
            type="email"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={styles.input}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={styles.input}
            required
          />
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <button type="submit" style={styles.button}>Log in</button>
        </form>
        <p style={styles.registerLink}>
          Don't you have an account? <Link to="/register">Register here</Link>
        </p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    backgroundImage: 'url("register.jpg")',
    backgroundSize: 'cover',
    position: 'relative',
  },
  leftSide: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    width: '50%',
  },
  monkeyImage: {
    width: '100%',
  },
  formContainer: {
    backgroundColor: 'rgba(240, 240, 240, 0.9)',
    padding: '60px',
    borderRadius: '30px',
    boxShadow: '0 0 15px rgba(0, 0, 0, 0.2)',
    width: '370px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    position: 'relative',
    height: '380px',
    overflow: 'visible',
  },
  cancelButton: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    color: '#ff5a5a',
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '22px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
  },
  input: {
    width: '100%',
    padding: '10px',
    margin: '10px 0',
    borderRadius: '20px',
    border: '1px solid #ccc',
    fontSize: '16px',
  },
  button: {
    width: '100%',
    padding: '10px',
    borderRadius: '20px',
    border: 'none',
    backgroundColor: '#4CAF50',
    color: 'white',
    fontSize: '16px',
    cursor: 'pointer',
    marginTop: '20px',
  },
  registerLink: {
    marginTop: '10px',
    textAlign: 'center',
  },
};

export default LoginPage;